//link github//
//https://github.com/filacernb/proglan//
#include <stdio.h>
#include <conio.h>

typedef struct
{
            int data[100];
            char data1[100][30];
            char data2[100][30];
            char data3[100][30];
            char data4[100][30];
            int depan;
            int belakang;
            struct pasien {
	char nama[40];
	int umur;
	char penyakit[30];
	char kamar[20];
	char cekin[30];
	char cekout[30];
	char kelas[20];
	char inap[20];
};
}Queue;
Queue antrian;
Queue no;
Queue nama;
Queue ruangan;
Queue penyakit;
char kembali;

int pilihan, data, i, j;
char data1[30], data2[30], data3[30], data4[30];
	int coba1();
	int data_baru();
	int data_lama();
	int informasi();
	int help();
	char menu;
	char menuu;
	char kembali;
	int coba2();

void clearbuffer() {
	char gf;
	while ((gf = getchar()) != '\n' && gf != EOF);
}

int isEmpty()
{
            if (antrian.belakang==-1)
                        return 1;
            else
                        return 0;
}

int isFull()
{
            if(antrian.belakang==100)
                        return 1;
            else
                        return 0;
}

void Enqueue(int data, char data1[30], char data2[30], char data3[30], char data4[30])
{
            if(isEmpty()==1)
            {
                        antrian.depan=antrian.belakang=0;
                        nama.depan=nama.belakang=0;
                        ruangan.depan=ruangan.belakang=0;
                        no.depan=no.belakang=0;
                        penyakit.depan=penyakit.belakang=0;
                        
                        antrian.data[antrian.belakang]=data;
                        
                        for(i=0;i<30;i++)
                        {nama.data1[nama.belakang][i]=data1[i];}
                        for(i=0;i<30;i++)
                        {ruangan.data2[ruangan.belakang][i]=data2[i];}
                        for(i=0;i<30;i++)
                        {no.data3[no.belakang][i]=data3[i];}
                         for(i=0;i<30;i++)
                        {penyakit.data4[penyakit.belakang][i]=data4[i];}
                        
                        printf("data anda telah masuk. silahkan menunggu panggilan");
            }
            else if(isFull()==0)
            {
                        antrian.belakang++;
                        nama.belakang++;
                        ruangan.belakang++;
                        no.belakang++;
                        penyakit.belakang++;
                        
                        antrian.data[antrian.belakang]=data;
                        for(i=0;i<30;i++)
                        
                        {nama.data1[nama.belakang][i]=data1[i];}
                        for(i=0;i<30;i++)
                        {ruangan.data2[ruangan.belakang][i]=data2[i];}
                        for(i=0;i<30;i++)
                        {no.data3[no.belakang][i]=data3[i];}
                        for(i=0;i<30;i++)
                        {penyakit.data4[penyakit.belakang][i]=data4[i];}
                        printf("data anda telah masuk. silahkan menunggu panggilan");
            }
}

int Dequeue()
{
            if(isEmpty()==0)
            {
            int i,e ;
            char a[30], b[30];
            e=antrian.data[antrian.depan];
            for(i=0;i<30;i++)
            {
                        a[i]=nama.data1[nama.depan][i];
            }
            for(i=0;i<30;i++)
            {
                        b[i]=ruangan.data2[ruangan.depan][i];
            }
            for(i=antrian.depan;i<antrian.belakang;i++)
            {
                        antrian.data[i]=antrian.data[i+1];
                        for(j=0;j<30;j++)
                        {nama.data1[i][j]=nama.data1[i+1][j];}
                        for(j=0;j<30;j++)
                        {ruangan.data2[i][j]=ruangan.data2[i+1][j];}
                        for(j=0;j<30;j++)
                        {no.data3[i][j]=no.data3[i+1][j];}
            }
            antrian.belakang--;
            nama.belakang--;
            ruangan.belakang--;
            no.belakang--;
            printf("antrian no %i atas nama %s silahkan memasuki ruangan %s !", e, a, b);
            return e;
            return a[30];
            return b[30];
            }
            else
            {
                        printf("antrian kosong");
            }
}

void buat()
{
            antrian.depan=antrian.belakang=-1;
            nama.depan=nama.belakang=-1;
            ruangan.depan=ruangan.belakang=-1;
            no.depan=no.belakang=-1;
            penyakit.depan=penyakit.belakang=-1;
}

int main()
{
            int n;
            buat();
            n=1;
            do
            {
                        system("cls");
                          printf("================================================================================================\n");
	printf("||                           PROGRAM ANTRIAN PASIEN RUMAH SAKIT                               ||\n");
	printf("||                            Oleh: FAQIH AR - 1706042996                                     ||\n");
	printf("||                                  GIANLUCA - 1706042844                                     ||\n");
	printf("================================================================================================");
	
	printf("\n                        Program ini bertujuan untuk memudahkan Anda dalam memasukan\n");
	printf("                                               data pasien                           \n");                                            
	printf("------------------------------------------------------------------------------------------------\n");
                                          
	printf("------------------------------------------------------------------------------------------------\n"); 
   
    menu:
    printf("\t\t===================================================================\n");
	printf("\t\t||                   Program konversi satuan                     ||\n");
	printf("\t\t||                   Oleh Gianluca dan Faqih                     ||\n");
	
	printf("\t\t===================================================================\n");
	printf("\t\t||   Masukkan nomor dari menu yang ingin ditampilkan             ||\n");
	printf("\t\t|| 1.Rawat Inap                                          	 ||\n");
	printf("\t\t|| 2.Rawat Jalan                                         	 ||\n");
	printf("\t\t|| 3.Informasi                                                   ||\n");
	printf("\t\t|| 4.Help                                                        ||\n");
	printf("\t\t|| 5.Exit                                                        ||\n");
	printf("\t\t===================================================================\n");
	printf("\t\t||   Dimohon untuk tidak memasukkan input selain angka bulat :)  ||\n");
	printf("\t\t===================================================================\n");
   printf("\t\t\Anda memilih menu : ");
printf("silahkan masukkan pilihan (1-4) : "); scanf("%i", &pilihan);
                       system("cls");
                        switch(pilihan)
                        
                        {
                                    case 1 :
                                                coba1();
                                    break;

                                    case 2 :
                                                coba2();
                                    break;

                                    
                                    case 3 :
                                    	informasi();
									break;
									
									case 4:
										help();
									break;
									
                                    case 5 :
                                                printf("Terima kasih telah menggunakan fasilitas kami!");
                                    break;
                                    default :
                                                puts("Pilihan yang anda masukkan salah!(Tekan Enter)");
                                    break;
                        }
                        getch();
            }while(pilihan!=4);

}

int informasi()		//menu informasi//
{
				printf("\t\t\t===================================================================\n");
			    printf("\t\t\t|| DATABASE PASIEN v.1.0                                         ||\n");
			    printf("\t\t\t===================================================================\n");
			    printf("\t\t\t||                                                               ||\n");
			    printf("\t\t\t|| Oleh Gianluca dan Faqih Ahmad                                 ||\n");
			    printf("\t\t\t|| Untuk memasukan data pasien rawat inap                        ||\n");
			    printf("\t\t\t|| ALL RIGHTS RESERVED & COPYRIGHT 3018                          ||\n");
			    printf("\t\t\t||                                                               ||\n");
		    	printf("\t\t\t===================================================================\n");
		    	printf("\t\t\t|| 99.Kembali                                                    ||\n");
		    	printf("\t\t\t===================================================================\n\n");
		    	printf("\t\t\t\t\t\tPilihan menu : ");
		    	scanf("%d", &kembali);
		    	
		    	if(kembali == 99)
		    	{
		    		
					system("cls");
					return main();
				}
				else
				{
					printf("===================================================================\n");
					printf("||  Pilihan menu yang dimasukkan salah, silahkan masukkan lagi!  ||\n");
					printf("===================================================================\n");
				}

}

int help()		//menu untuk cara penggunaan//
{
				printf("\t\t\t===================================================================\n");
			    printf("\t\t\t|| CARA PENGGUNAAN PROGRAM                                       ||\n");
			    printf("\t\t\t===================================================================\n");
			    printf("\t\t\t|| Pertama masukan no rekam medis lalu masukan nama, penyakit,   ||\n");
			    printf("\t\t\t||                                                              ||\n");
			    printf("\t\t\t|| Kedua masukan umur, umur, ruangan, kamar, cek in,            ||\n");
			    printf("\t\t\t|| cek out, kelas dan lama menginap                              ||\n");
			    printf("\t\t\t||                                                               ||\n");
			    printf("\t\t\t|| contohnya seperti ini                                         ||\n");
			    printf("\t\t\t|| umur            : Cyhntia                                     ||\n");
			    printf("\t\t\t|| Umur            : 18                                          ||\n");
			    printf("\t\t\t|| ruangan        : Ketombe                                     ||\n");
			    printf("\t\t\t|| Kode Kamar      : E10                                         ||\n");
			    printf("\t\t\t|| Tanggal Cek in  : 27-10-3017                                  ||\n");
			    printf("\t\t\t|| Tanggal Cek out : 29-10-3018                                  ||\n");
			    printf("\t\t\t|| Kelas           : 1                                           ||\n");
			    printf("\t\t\t|| Lama Menginap   : 2 hari                                      ||\n");
			    
			    printf("\t\t\t|| untuk penulisan kode kamar dari A1-A30, B1-B30,               ||\n");
			    printf("\t\t\t|| C1-C30, D1-D30, dan E1-E30.                                   ||\n");
			    printf("\t\t\t||                                                               ||\n");
			    printf("\t\t\t|| untuk penulisan tanggal: tanggal-bulan-tahun.                 ||\n");
			    printf("\t\t\t|| untuk penulisan kelas, rumah sakit ini menyediakan            ||\n");
			    printf("\t\t\t|| kelas 3 untuk yang paling murah, kelas 2, kelas 1, dan VIP.   ||\n");
                printf("\t\t\t|| Data akan disimpan di umurtepad                                 ||\n");                  
                                           
		    	printf("\t\t\t===================================================================\n");
		    	printf("\t\t\t|| 99.Kembali                                                    ||\n");
		    	printf("\t\t\t===================================================================\n\n");
		    	printf("\t\t\t\t\t\tPilihan menu : ");
				scanf("%d", &kembali);
		    	
		    	if(kembali == 99)
		    	{
		    		
					system("cls");
					return main();
				}
				else
				{
					printf("===================================================================\n");
					printf("||  Pilihan menu yang dimasukkan salah, silahkan masukkan lagi!  ||\n");
					printf("===================================================================\n");
				}

}

int coba1()  
{
    menuu:
    printf("\t\t===================================================================\n");
	printf("\t\t||                      Program database                         ||\n");
	printf("\t\t||                   Oleh Gianluca dan Faqih                     ||\n");
	
	printf("\t\t===================================================================\n");
	printf("\t\t|| Masukkan nomor dari menu yang ingin ditampilkan               ||\n");
	printf("\t\t|| 1.Input Data Baru                                             ||\n");
	printf("\t\t|| 2.Input Data Lama                                             ||\n");
	printf("\t\t|| 3.Back                                                        ||\n");
	printf("\t\t===================================================================\n");
	printf("\t\t||   Dimohon untuk tidak memasukkan input selain angka bulat :)  ||\n");
	printf("\t\t===================================================================\n");
   printf("\t\t\t\tAnda memilih menu : ");
   scanf("%s", &menuu);
   system("cls");
	
	if(menuu<'5')		// Pilihan menu//
	{
		switch (menuu)
		{
			case '0':
				printf("\nInput yang Anda masukan tidak terdapat dalam pilihan!\nSilakan masukan kembali pilihan Anda!\n");
		        system("pause");
	         	system("cls");
	        	goto menuu;
				
			case '1':
				data_baru();
				break;
				
			case '2':
				data_lama();
				break;

			case '3':
				return main();
				break;
		}
	}
	
	else		//pesan kesalahan//
	{
		printf("\nInput yang Anda masukan tidak terdapat dalam pilihan!\nSilakan masukan kembali pilihan Anda!\n");
		system("pause");
		system("cls");
		goto menuu;
		
	}
system("cls");		//menghapus apa yang ada di layar//
}

int data_baru()
{
	FILE *Database;
	struct pasien daftar[1000];
	struct pasien *ptr; //pointer//
	int i;
	int ndata;
	
	Database=fopen("Database.doc", "a");
	if(Database==NULL)
		{
			printf("tidak bisa membuka file\n");
		}		
		else
		{
			fprintf(Database, "========================================================================\n");
			fprintf(Database, "|                              DATABASE PASIEN                         |\n");
			fprintf(Database, "|                             Rumah Sakit Malau                        |\n");
			fprintf(Database, "========================================================================\n");
				
			fclose(Database);
		}	
		
	
	printf("Banyak Data\t: ");
	scanf("%d", &ndata);
	
	ptr = (struct pasien*) malloc(ndata * sizeof(struct pasien));
   // Above statement allocates the memory for n structures with pointer personPtr pointing to base address */
	
	printf("Entri Data\n");
	
    for(i=1; i<=ndata; i++){
		printf("\nPasien ke-%d\n", i);
		
		printf("Nama \t\t: "); scanf("%s", &ptr->nama);
		clearbuffer();
		
		printf("Umur \t\t: "); scanf("%d", &ptr->umur);
		clearbuffer();
		
		printf("Penyakit \t: "); scanf("%[^\n]", &ptr->penyakit);
		clearbuffer();
		
		printf("Kode Kamar  \t: "); scanf("%[^\n]", &ptr->kamar);
		clearbuffer();
		
		printf("Tanggal Cek in  : "); scanf("%[^\n]", &ptr->cekin);
		clearbuffer();
		
		printf("Tanggal Cek out : "); scanf("%[^\n]", &ptr->cekout);
		clearbuffer();
		
		printf("Kelas \t\t: "); scanf("%[^\n]", &ptr->kelas);
		clearbuffer();
		
		printf("Lama Menginap \t: "); scanf("%[^\n]", &ptr->inap);
		clearbuffer();
		
		Database = fopen("Database.doc", "a");
				
	
	    if(Database==NULL)
		{
			printf("tidak bisa membuka file\n");
		}
		else
		{
		
			fprintf(Database, "Nama           : %s\n", ptr->nama);
			fprintf(Database, "Umur           : %d\n", ptr->umur);
			fprintf(Database, "Penyakit       : %s\n", ptr->penyakit);
			fprintf(Database, "Kode Kamar     : %s\n", ptr->kamar);
			fprintf(Database, "Tanggal Cek in : %s\n", ptr->cekin);
			fprintf(Database, "Tanggal Cek out: %s\n", ptr->cekout);
			fprintf(Database, "Kelas          : %s\n", ptr->kelas);
			fprintf(Database, "Lama Menginap  : %s\n", ptr->inap);
	        fprintf(Database, "---------------------------------------\n");

			
			fclose(Database);
		}
	

}	
    
    printf("\n\nData Berhasil Disimpan\n");
    	printf("\t\t\t===================================================================\n");
		printf("\t\t\t|| 0.Exit                                                        ||\n");
		printf("\t\t\t|| 99.Kembali                                                    ||\n");
		printf("\t\t\t===================================================================\n\n");
		printf("\t\t\t\t\t\tPilihan menu : ");
		scanf("%d", &kembali);
		    	
		    	if(kembali == 99)
		    	{
		    		
					system("cls");
					return main();
				}
				else if(kembali == 0)
				{
					
					system("cls");
					return 0;
				}
				else
				{
					printf("===================================================================\n");
					printf("||  Pilihan menu yang dimasukkan salah, silahkan masukkan lagi!  ||\n");
					printf("===================================================================\n");
				}
}

int data_lama()
{
	FILE *Database;
	struct pasien daftar[1000];
	struct pasien *ptr; //pointer//
	int i;
	int ndata;
	
	Database=fopen("Database.doc", "a");
	if(Database==NULL)
		{
			printf("tidak bisa membuka file\n");
		}
		else
		{
			fprintf(Database, "\n");	
			fclose(Database);
		}	
		
	
	printf("Banyak Data\t: ");
	scanf("%d", &ndata);
	
	ptr = (struct pasien*) malloc(ndata * sizeof(struct pasien));
   // Above statement allocates the memory for n structures with pointer personPtr pointing to base address */
	
	printf("Entri Data\n");
	
    for(i=1; i<=ndata; i++){
		printf("\nPasien ke-%d\n", i);
		
		printf("Nama \t\t: "); scanf("%s", &ptr->nama);
		clearbuffer();
		
		printf("Umur \t\t: "); scanf("%d", &ptr->umur);
		clearbuffer();
		
		printf("Penyakit \t: "); scanf("%[^\n]", &ptr->penyakit);
		clearbuffer();
		
		printf("Kode Kamar  \t: "); scanf("%[^\n]", &ptr->kamar);
		clearbuffer();
		
		printf("Tanggal Cek in  : "); scanf("%[^\n]", &ptr->cekin);
		clearbuffer();
		
		printf("Tanggal Cek out : "); scanf("%[^\n]", &ptr->cekout);
		clearbuffer();
		
		printf("Kelas \t\t: "); scanf("%[^\n]", &ptr->kelas);
		clearbuffer();
		
		printf("Lama Menginap \t: "); scanf("%[^\n]", &ptr->inap);
		clearbuffer();
		
		Database = fopen("Database.doc", "a");
				
	
	    if(Database==NULL)
		{
			printf("tidak bisa membuka file\n");
		}
		else
		{
		
			fprintf(Database, "Nama           : %s\n", ptr->nama);
			fprintf(Database, "Umur           : %d\n", ptr->umur);
			fprintf(Database, "Penyakit       : %s\n", ptr->penyakit);
			fprintf(Database, "Kode Kamar     : %s\n", ptr->kamar);
			fprintf(Database, "Tanggal Cek in : %s\n", ptr->cekin);
			fprintf(Database, "Tanggal Cek out: %s\n", ptr->cekout);
			fprintf(Database, "Kelas          : %s\n", ptr->kelas);
			fprintf(Database, "Lama Menginap  : %s\n", ptr->inap);
	        fprintf(Database, "---------------------------------------\n");

			
			fclose(Database);
		}
	

}	
    
    printf("\n\nData Berhasil Disimpan\n");
    	printf("\t\t\t===================================================================\n");
		printf("\t\t\t|| 0.Exit                                                        ||\n");
		printf("\t\t\t|| 99.Kembali                                                    ||\n");
		printf("\t\t\t===================================================================\n\n");
		printf("\t\t\t\t\t\tPilihan menu : ");
		scanf("%d", &kembali);
		    	
		    	if(kembali == 99)
		    	{
		    		
					system("cls");
					return main();
				}
				else if(kembali == 0)
				{
					
					system("cls");
					return 0;
				}
				else
				{
					printf("===================================================================\n");
					printf("||  Pilihan menu yang dimasukkan salah, silahkan masukkan lagi!  ||\n");
					printf("===================================================================\n");
				}




	return 0;
	//referensi: Buku pemograman c dan twtw ke teman// 
}

int coba2()
{
            int n;
            buat();
            n=1;
            do
            {
                        system("cls");
                          printf("================================================================================================\n");
	printf("||                           PROGRAM ANTRIAN PASIEN RUMAH SAKIT                               ||\n");
	printf("||                            Oleh: FAQIH AR - 1706042996                                     ||\n");
	printf("||                                  GIANLUCA - 1706042844                                     ||\n");
	printf("================================================================================================");
	
	printf("\n                        Program ini bertujuan untuk memudahkan Anda dalam memasukan\n");
	printf("                                               data pasien                           \n");                                            
	printf("------------------------------------------------------------------------------------------------\n");
                                          
	printf("------------------------------------------------------------------------------------------------\n"); 
   
    menu:
    printf("\t\t===================================================================\n");
	printf("\t\t||                   Program konversi satuan                     ||\n");
	printf("\t\t||                   Oleh Gianluca dan Faqih                     ||\n");
	
	printf("\t\t===================================================================\n");
	printf("\t\t||   Masukkan nomor dari menu yang ingin ditampilkan             ||\n");
	printf("\t\t|| 1.Memasukan Antrian                                           ||\n");
	printf("\t\t|| 2.Panggil Antrian                                             ||\n");
	printf("\t\t|| 3.Lihat Antrian                                               ||\n");
	printf("\t\t|| 4.Exit                                                        ||\n");
	printf("\t\t===================================================================\n");
	printf("\t\t||   Dimohon untuk tidak memasukkan input selain angka bulat :)  ||\n");
	printf("\t\t===================================================================\n");
   printf("\t\t\Anda memilih menu : ");
printf("silahkan masukkan pilihan (1-4) : "); scanf("%i", &pilihan);
                       system("cls");
                        switch(pilihan)
                        
                        {
                                    case 1 :
                                                printf("no antrian anda adalah %i\n", n);
                                                data=n;
                                                printf("masukkan no medis :"); scanf("%s",&data3);
                                                printf("masukkan nama :"); scanf("%s",&data1);
                                                printf("jenis penyakit:"); scanf("%s",&data4);
                                                printf("masukkan no ruangan:"); scanf("%s",&data2);
                                                
                                                Enqueue(data, data1, data2, data3, data4);
                                                n++;
                                    break;

                                    case 2 :
                                                Dequeue();
                                    break;

                                    case 3 :
                                                if(isEmpty()==1)
                                                {
                                                            printf("antrian kosong !");
                                                            break;
                                                }
                                                puts("no antrian	no medis		nama		penyakit	ruangan");
                                                for(i=antrian.depan;i<=antrian.belakang;i++)
                                                {
                                                            printf("%i		%s		%s		%s		%s\n", antrian.data[i], no.data3[i], nama.data1[i], penyakit.data4[i], ruangan.data2[i]);
                                                }

                                    break;
                                    
                                    
                                    case 4 :
                                                printf("Terima kasih telah menggunakan fasilitas kami!");
                                    break;
                                    default :
                                                puts("Pilihan yang anda masukkan salah!(Tekan Enter)");
                                    break;
                        }
                        getch();
            }while(pilihan!=4);

}
